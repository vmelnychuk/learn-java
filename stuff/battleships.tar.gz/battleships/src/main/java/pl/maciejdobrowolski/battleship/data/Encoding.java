package pl.maciejdobrowolski.battleship.data;

public enum Encoding {
    CP1250
}