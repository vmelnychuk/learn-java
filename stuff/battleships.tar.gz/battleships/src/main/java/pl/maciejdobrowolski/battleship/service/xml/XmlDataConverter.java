package pl.maciejdobrowolski.battleship.service.xml;

import static java.util.stream.Collectors.*;
import static javafx.scene.text.Font.*;
import static javafx.scene.text.FontWeight.*;

import java.util.List;

import javafx.scene.text.Font;
import pl.maciejdobrowolski.battleship.data.Element;

class XmlDataConverter {

    public List<Element> toElements(List<Text> texts) {
        return texts.stream()
                .map(this::toElement)
                .collect(toList());
    }

    private Element toElement(Text text) {
        Element element = new Element();
        element.setX(text.getX());
        element.setY(text.getY());
        element.setText(text.getText());
        element.setPageNumber(text.getPageNumber());
        element.setFont(font(text.getFontName(), text.isBold() ? BOLD : NORMAL, text.getFontSize()));
        return element;
    }

    public List<Text> fromElements(List<Element> elements) {
        return elements.stream()
                .map(this::fromElement)
                .collect(toList());
    }

    private Text fromElement(Element element) {
        return new Text(
                element.getX(),
                element.getY(),
                element.getPageNumber(),
                element.getText(),
                element.getFont().getFamily(),
                isBold(element.getFont()),
                element.getFont().getSize());
    }

    private static boolean isBold(Font font) {
        return font.getName().toLowerCase().contains("bold");
    }

}
