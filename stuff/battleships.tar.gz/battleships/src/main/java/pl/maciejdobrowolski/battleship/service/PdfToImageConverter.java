package pl.maciejdobrowolski.battleship.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.icepdf.core.pobjects.Document;
import org.icepdf.core.pobjects.Page;
import org.icepdf.core.util.GraphicsRenderingHints;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

class PdfToImageConverter {

    private static final float SCALE = 2.0f;
    private static final float ROTATION = 0f;

    List<Image> convert(File file) {
        Document document = getDocument(file);
        List<Image> images = new ArrayList<>();
        for (int i = 0; i < document.getNumberOfPages(); i++) {
            Image image = getSinglePageImage(document, i);
            images.add(image);
        }
        return images;
    }

    private Document getDocument(File file) {
        try {
            Document document = new Document();
            URL fileUrl = file.toURI().toURL();
            document.setUrl(fileUrl);
            return document;
        } catch (Exception e) {
            throw new RuntimeException("Error while converting file to document", e);
        }
    }

    private Image getSinglePageImage(Document document, int i) {
        BufferedImage bufferedImage = (BufferedImage) document.getPageImage(i, GraphicsRenderingHints.SCREEN, Page.BOUNDARY_CROPBOX, ROTATION, SCALE);
        Image image = SwingFXUtils.toFXImage(bufferedImage, null);
        bufferedImage.flush();
        return image;
    }

}
