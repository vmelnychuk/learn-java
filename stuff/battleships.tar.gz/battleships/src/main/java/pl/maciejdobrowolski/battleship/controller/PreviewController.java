package pl.maciejdobrowolski.battleship.controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.beans.InvalidationListener;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import pl.maciejdobrowolski.battleship.control.ElementLabel;
import pl.maciejdobrowolski.battleship.control.Paginator;
import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.data.Project;
import pl.maciejdobrowolski.battleship.event.ElementSelectedEvent;
import pl.maciejdobrowolski.battleship.event.Events;

public class PreviewController implements Initializable {

    @FXML
    private StackPane imageStack;

    @FXML
    private ImageView imageView;

    @FXML
    private Paginator pagination;

    @FXML
    private AnchorPane labelsLayer;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        bindSizeForLabelsLayer();
        imageStack.setOnMouseClicked(event -> Events.fire(new ElementSelectedEvent(null)));
    }

    private void bindSizeForLabelsLayer() {
        // setting minSize due to http://bugs.java.com/bugdatabase/view_bug.do?bug_id=JDK-8163075
        labelsLayer.minHeightProperty().bind(imageView.fitHeightProperty());
        labelsLayer.minWidthProperty().bind(imageView.fitWidthProperty());
        labelsLayer.prefHeightProperty().bind(imageView.fitHeightProperty());
        labelsLayer.prefWidthProperty().bind(imageView.fitWidthProperty());
    }

    void bindProject(SimpleObjectProperty<Project> observableProject) {
        observableProject.addListener((observable, oldProject, newProject) -> {
            if (newProject != null) {
                pagination.maxPagesProperty().bind(newProject.totalPages());
                IntegerBinding pageIndex = pagination.currentPageProperty().subtract(1);
                imageView.imageProperty().bind(newProject.pageAtIndex(pageIndex));

                bindElements(newProject.getElements());
            }
        });
    }

    private void bindElements(ObservableList<Element> elements) {
        elements.addListener((InvalidationListener) changed -> redrawLabels(elements));
        pagination.currentPageProperty().addListener(changed -> redrawLabels(elements));
        redrawLabels(elements);
    }

    private void redrawLabels(ObservableList<Element> elements) {
        List<ElementLabel> elementLabels = elements.stream()
                .filter(element -> element.getPageNumber() == pagination.getCurrentPage())
                .map(ElementLabel::new)
                .collect(Collectors.toList());
        labelsLayer.getChildren().setAll(elementLabels);
    }
}
