package pl.maciejdobrowolski.battleship.control;

import javafx.beans.binding.When;
import javafx.event.Event;
import javafx.geometry.Point2D;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.event.ElementSelectedEvent;
import pl.maciejdobrowolski.battleship.event.Events;

public class ElementLabel extends Label {

    private static final String SELECTED_BORDER = "-fx-border-width: 1px solid; -fx-border-color: black";

    private static final String NOT_SELECTED_BORDER = "-fx-border-width: 1px solid; -fx-border-color: transparent";

    private Element element;

    public ElementLabel(Element element) {
        this.element = element;
        setFocusTraversable(false);
        bindProperties();
        bindMouseBehaviour();
    }

    private void bindProperties() {
        // todo: another place when pdf zoom factor is used
        setScaleX(2.0);
        setScaleY(2.0);

        fontProperty().bind(element.fontProperty());
        textProperty().bind(element.textProperty());

        moveElement(element);
        element.yProperty().addListener(invalidated -> moveElement(element));
        element.xProperty().addListener(invalidated -> moveElement(element));

        styleProperty().bind(new When(element.selectedProperty())
                .then(SELECTED_BORDER)
                .otherwise(NOT_SELECTED_BORDER));
    }

    private void bindMouseBehaviour() {
        setOnMouseClicked(Event::consume);

        setOnMouseEntered(event -> setCursor(Cursor.HAND));

        setOnMousePressed(event -> {
            fireElementSelected(element);
            event.consume();
        });

        setOnMouseDragged(event -> {
            // todo: probably there's a need to take into the account the height of label because the system in cola
            // looks at the bottom of label and this one - top border.
            Node parent = getParent();
            Point2D localCoordinates = parent.sceneToLocal(event.getSceneX(), event.getSceneY());
            element.setX((int) (localToXmlX(localCoordinates.getX())));
            element.setY((int) (localToXmlY(parent.getBoundsInLocal().getHeight() - localCoordinates.getY())));
            event.consume();
        });

        setOnMouseReleased(event -> {
            setCursor(Cursor.HAND);
            event.consume();
        });
    }

    private void fireElementSelected(Element element) {
        Events.fire(new ElementSelectedEvent(element));
    }

    // todo: extract this / correlate it with pdf2image zoom factor
    private double xmlToLocalX(double x) {
        return x * 2;
    }

    private double xmlToLocalY(double y) {
        return y * 2;
    }

    private double localToXmlX(double x) {
        return x / 2;
    }

    private double localToXmlY(double y) {
        return y / 2;
    }

    private void moveElement(Element element) {
        double x = element.getX();
        double y = element.getY();
        if (x >= 0 && y >= 0) {
            AnchorPane.setLeftAnchor(this, xmlToLocalX(x));
            AnchorPane.setBottomAnchor(this, xmlToLocalY(y));
        }
    }

}
