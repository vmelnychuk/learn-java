package pl.maciejdobrowolski.battleship.control;

import static java.util.Optional.*;

import java.util.function.Consumer;
import java.util.function.Supplier;

import com.google.common.eventbus.Subscribe;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.data.Project;
import pl.maciejdobrowolski.battleship.event.ElementSelectedEvent;
import pl.maciejdobrowolski.battleship.event.Events;

public class ElementListView extends ListView<Element> {

    private static final SimpleListProperty<Element> EMPTY_LIST = new SimpleListProperty<>();

    private Supplier<Element> addAction;
    private Consumer<Element> removeAction;

    public ElementListView() {
        setCellFactory(new ElementListCellFactory());
        Events.register(this);
        setContextMenu(new ElementsContextMenu());
    }

    public void bindProject(SimpleObjectProperty<Project> project) {
        project.addListener(invalidated -> {
            itemsProperty().bind(
                    ofNullable(project.get())
                            .map(Project::elementsProperty)
                            .orElse(EMPTY_LIST));
        });
    }

    public void setAddAction(Supplier<Element> addAction) {
        this.addAction = addAction;
    }

    public void setRemoveAction(Consumer<Element> removeAction) {
        this.removeAction = removeAction;
    }

    @Subscribe
    public void onElementSelected(ElementSelectedEvent event) {
        if (event.isPresent()) {
            getSelectionModel().select(event.getElement());
        } else {
            getSelectionModel().clearSelection();
        }
    }

    private class ElementsContextMenu extends ContextMenu {
        final MenuItem addElementMenuItem = new MenuItem("Add new element");
        final MenuItem removeElementMenuItem = new MenuItem("Remove selected element");

        ElementsContextMenu() {
            addElementMenuItem.setOnAction((event) -> addAction.get());
            removeElementMenuItem.setOnAction((event) -> removeAction.accept(getSelectionModel().getSelectedItem()));
            removeElementMenuItem.disableProperty()
                    .bind(Bindings.size(getSelectionModel().getSelectedItems()).lessThanOrEqualTo(0));

            getItems().addAll(addElementMenuItem, removeElementMenuItem);
        }
    }

}
