package pl.maciejdobrowolski.battleship.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.data.Project;
import pl.maciejdobrowolski.battleship.service.xml.XmlReaderWriter;

class ProjectSaver {

    private XmlReaderWriter readerWriter = new XmlReaderWriter();

    void save(Project project) {
        File xmlFile = project.getXmlFile();
        List<Element> Elements = project.getElements();
        String xml = readerWriter.toXml(Elements);
        try (FileWriter fileWriter = new FileWriter(xmlFile)) {
            fileWriter.write(xml);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
