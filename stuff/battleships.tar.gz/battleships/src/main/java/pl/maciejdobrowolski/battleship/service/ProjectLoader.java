package pl.maciejdobrowolski.battleship.service;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

import javafx.scene.image.Image;
import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.data.Project;

class ProjectLoader {

    private static final String XML_FILE_SUFFIX = ".xml";

    Project load(File pdfFile) {
        File xmlFile = resolveXmlFileForPdf(pdfFile);
        List<Image> pages = loadPages(pdfFile);
        List<Element> elements = loadData(xmlFile);
        return new Project(pdfFile, xmlFile, elements, pages);
    }

    private List<Image> loadPages(File pdfFile) {
        PdfToImageConverter pdfToImageConverter = new PdfToImageConverter();
        return pdfToImageConverter
                .convert(pdfFile).stream()
                .collect(Collectors.toList());
    }

    private List<Element> loadData(File xmlFile) {
        XmlFileLoader xmlFileLoader = new XmlFileLoader();
        return xmlFileLoader.loadDocumentElementsForPDF(xmlFile);
    }

    private File resolveXmlFileForPdf(File pdfFile) {
        String pdfAbsolutePath = pdfFile.getAbsolutePath();
        int indexOfDot = pdfAbsolutePath.lastIndexOf(".");
        String xmlAbsolutePath = pdfAbsolutePath.substring(0, indexOfDot) + XML_FILE_SUFFIX;
        return new File(xmlAbsolutePath);
    }

}
