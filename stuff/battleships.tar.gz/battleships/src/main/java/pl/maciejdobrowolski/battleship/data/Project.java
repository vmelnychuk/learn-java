package pl.maciejdobrowolski.battleship.data;

import static javafx.collections.FXCollections.*;

import java.io.File;
import java.util.List;

import javafx.beans.binding.IntegerBinding;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableIntegerValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import pl.maciejdobrowolski.battleship.SampleElementFactory;

public class Project {

    public static final Project EMPTY_PROJECT = new Project();

    private File pdfFile;
    private File xmlFile;
    private SimpleListProperty<Element> elements = new SimpleListProperty<>(observableArrayList());
    private SimpleListProperty<Image> pages = new SimpleListProperty<>(observableArrayList());

    private Project() {
    }

    public Project(File pdfFile, File xmlFile, List<Element> elements, List<Image> pages) {
        this.pdfFile = pdfFile;
        this.xmlFile = xmlFile;
        this.elements = new SimpleListProperty<>(observableArrayList(elements));
        this.pages = new SimpleListProperty<>(observableArrayList(pages));
    }

    public Element newElement() {
        Element element = SampleElementFactory.getRandom();
        elements.add(element);
        return element;
    }

    public void removeElement(Element element) {
        elements.remove(element);
    }

    public ObservableList<Element> getElements() {
        return elements.get();
    }

    public SimpleListProperty<Element> elementsProperty() {
        return elements;
    }

    public ObservableList<Image> getPages() {
        return pages.get();
    }

    public SimpleListProperty<Image> pagesProperty() {
        return pages;
    }

    public ObservableIntegerValue totalPages() {
        return pages.sizeProperty();
    }

    public ObservableValue<? extends Image> pageAtIndex(IntegerBinding pageIndex) {
        return pages.valueAt(pageIndex);
    }

    public File getPdfFile() {
        return pdfFile;
    }

    public File getXmlFile() {
        return xmlFile;
    }
}
