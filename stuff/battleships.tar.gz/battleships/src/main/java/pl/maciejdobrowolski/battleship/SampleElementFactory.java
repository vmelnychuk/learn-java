package pl.maciejdobrowolski.battleship;

import java.util.Random;

import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.data.Encoding;

public class SampleElementFactory {

    public static Element getRandom() {
        Element element = new Element();
        element.setText("Jan Kowalski");
        element.setEncoding(Encoding.CP1250);
        element.setFont(Font.font("Calibri", FontWeight.NORMAL, 16.0));
        element.setPageNumber(1);
        element.setX(new Random().nextInt(300));
        element.setY(new Random().nextInt(300));
        return element;
    }

}
