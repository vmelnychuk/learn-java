package pl.maciejdobrowolski.battleship.control;

import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.event.ElementSelectedEvent;
import pl.maciejdobrowolski.battleship.event.Events;

class ElementListCellFactory implements Callback<ListView<Element>, ListCell<Element>> {
    @Override
    public ListCell<Element> call(ListView<Element> param) {
        return new ListCell<Element>() {

            @Override
            public void updateSelected(boolean selected) {
                super.updateSelected(selected);
                if (selected) {
                    Events.fire(new ElementSelectedEvent(getItem()));
                }
            }

            @Override
            protected void updateItem(Element item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null) {
                    textProperty().bind(item.textProperty());
                } else {
                    textProperty().unbind();
                    setText("");
                }
            }
        };
    }
}

