package pl.maciejdobrowolski.battleship.service.xml;

import com.google.common.base.Objects;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("text")
class Text {

    @XStreamAsAttribute
    private final int x;

    @XStreamAsAttribute
    private final int y;

    @XStreamAsAttribute
    private final int pageNumber;

    @XStreamAsAttribute
    private final String text;

    @XStreamAsAttribute
    private final String fontName;

    @XStreamAsAttribute
    private final boolean bold;

    @XStreamAsAttribute
    private final double fontSize;

    public Text(int x, int y, int pageNumber, String text, String fontName, boolean bold, double fontSize) {
        this.x = x;
        this.y = y;
        this.pageNumber = pageNumber;
        this.text = text;
        this.fontName = fontName;
        this.bold = bold;
        this.fontSize = fontSize;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public String getText() {
        return text;
    }

    public String getFontName() {
        return fontName;
    }

    public boolean isBold() {
        return bold;
    }

    public double getFontSize() {
        return fontSize;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Text text1 = (Text) o;
        return x == text1.x &&
                y == text1.y &&
                pageNumber == text1.pageNumber &&
                bold == text1.bold &&
                fontSize == text1.fontSize &&
                Objects.equal(text, text1.text) &&
                Objects.equal(fontName, text1.fontName);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(x, y, pageNumber, text, fontName, bold, fontSize);
    }
}