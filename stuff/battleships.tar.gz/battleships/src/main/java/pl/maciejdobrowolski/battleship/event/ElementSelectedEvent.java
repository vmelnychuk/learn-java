package pl.maciejdobrowolski.battleship.event;

import pl.maciejdobrowolski.battleship.data.Element;

public class ElementSelectedEvent {

    private Element element;

    public ElementSelectedEvent(Element element) {
        this.element = element;
    }

    public Element getElement() {
        return element;
    }

    public boolean isPresent() {
        return element != null;
    }
}
