package pl.maciejdobrowolski.battleship.service.xml;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("stamps")
class Stamps {

    @XStreamImplicit(itemFieldName = "text")
    private final List<Text> items;

    public Stamps(List<Text> items) {
        this.items = items;
    }

    public List<Text> getItems() {
        return items;
    }
}
