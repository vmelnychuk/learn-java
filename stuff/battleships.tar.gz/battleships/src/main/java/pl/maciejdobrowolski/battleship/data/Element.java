package pl.maciejdobrowolski.battleship.data;

import com.google.common.eventbus.Subscribe;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.text.Font;
import pl.maciejdobrowolski.battleship.event.ElementSelectedEvent;
import pl.maciejdobrowolski.battleship.event.Events;

public class Element {

    private SimpleIntegerProperty x = new SimpleIntegerProperty();
    private SimpleIntegerProperty y = new SimpleIntegerProperty();
    private SimpleIntegerProperty pageNumber = new SimpleIntegerProperty();
    private SimpleStringProperty text = new SimpleStringProperty();
    private SimpleObjectProperty<Encoding> encoding = new SimpleObjectProperty<>(Encoding.CP1250);
    private SimpleObjectProperty<Font> font = new SimpleObjectProperty<>();

    private SimpleBooleanProperty selected = new SimpleBooleanProperty(false);

    public Element() {
        Events.register(this);
    }

    public int getX() {
        return x.get();
    }

    public SimpleIntegerProperty xProperty() {
        return x;
    }

    public void setX(int x) {
        this.x.set(x);
    }

    public int getY() {
        return y.get();
    }

    public SimpleIntegerProperty yProperty() {
        return y;
    }

    public void setY(int y) {
        this.y.set(y);
    }

    public int getPageNumber() {
        return pageNumber.get();
    }

    public SimpleIntegerProperty pageNumberProperty() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber.set(pageNumber);
    }

    public String getText() {
        return text.get();
    }

    public SimpleStringProperty textProperty() {
        return text;
    }

    public void setText(String text) {
        this.text.set(text);
    }

    public Encoding getEncoding() {
        return encoding.get();
    }

    public SimpleObjectProperty<Encoding> encodingProperty() {
        return encoding;
    }

    public void setEncoding(Encoding encoding) {
        this.encoding.set(encoding);
    }

    public Font getFont() {
        return font.get();
    }

    public SimpleObjectProperty<Font> fontProperty() {
        return font;
    }

    public void setFont(Font font) {
        this.font.set(font);
    }

    public SimpleBooleanProperty selectedProperty() {
        return selected;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Element element = (Element) o;

        if (!x.equals(element.x)) return false;
        if (!y.equals(element.y)) return false;
        if (!pageNumber.equals(element.pageNumber)) return false;
        if (!text.equals(element.text)) return false;
        if (!encoding.equals(element.encoding)) return false;
        if (!font.equals(element.font)) return false;
        return selected.equals(element.selected);

    }

    @Override
    public int hashCode() {
        int result = x.hashCode();
        result = 31 * result + y.hashCode();
        result = 31 * result + pageNumber.hashCode();
        result = 31 * result + text.hashCode();
        result = 31 * result + encoding.hashCode();
        result = 31 * result + font.hashCode();
        result = 31 * result + selected.hashCode();
        return result;
    }

    @Subscribe
    private void onElementSelected(ElementSelectedEvent event) {
        selected.set(this.equals(event.getElement()));
    }
}
