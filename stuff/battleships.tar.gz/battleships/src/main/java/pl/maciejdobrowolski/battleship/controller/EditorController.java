package pl.maciejdobrowolski.battleship.controller;

import static java.util.Optional.*;
import static javafx.beans.binding.Bindings.*;
import static org.controlsfx.property.BeanPropertyUtils.*;
import static org.controlsfx.tools.Utils.*;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import org.controlsfx.control.PropertySheet;
import org.controlsfx.control.StatusBar;

import com.google.common.eventbus.Subscribe;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import pl.maciejdobrowolski.battleship.control.ElementListView;
import pl.maciejdobrowolski.battleship.data.Project;
import pl.maciejdobrowolski.battleship.event.ElementSelectedEvent;
import pl.maciejdobrowolski.battleship.event.Events;
import pl.maciejdobrowolski.battleship.service.ProjectLoadService;
import pl.maciejdobrowolski.battleship.service.ProjectSaveService;
import pl.maciejdobrowolski.battleship.util.PdfFileChooser;

public class EditorController implements Initializable {

    @FXML
    private Node root;

    @FXML
    private PreviewController previewController;

    @FXML
    private PropertySheet elementProperty;

    @FXML
    private ElementListView elementList;

    @FXML
    private StatusBar statusBar;

    private SimpleObjectProperty<Project> project = new SimpleObjectProperty<>();

    private ProjectLoadService projectLoadService = new ProjectLoadService();
    private ProjectSaveService projectSaveService = new ProjectSaveService();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        previewController.bindProject(project);
        elementList.bindProject(project);
        elementList.setAddAction(() -> getCurrentProject().map(Project::newElement).get());
        elementList.setRemoveAction(element -> getCurrentProject().ifPresent((p) -> p.removeElement(element)));
        project.bind(
                when(isNotNull(projectLoadService.valueProperty()))
                .then(projectLoadService.valueProperty())
                .otherwise(Project.EMPTY_PROJECT)
        );

        Events.register(this);
    }

    private Optional<Project> getCurrentProject() {
        return ofNullable(project.get());
    }

    @FXML
    public void onOpenFile() {
        PdfFileChooser pdfFileChooser = new PdfFileChooser(getWindow(root));
        bindStatusBar(projectLoadService);
        pdfFileChooser.selectPdfFile()
                .ifPresent(projectLoadService::load);
    }

    @FXML
    public void onSaveFile() {
        bindStatusBar(projectSaveService);
        getCurrentProject()
                .ifPresent(projectSaveService::save);
    }

    @FXML
    public void onClose() {
        Platform.exit();
    }

    @Subscribe
    public void onElementSelected(ElementSelectedEvent event) {
        if (event.isPresent()) {
            ObservableList<PropertySheet.Item> elementProperties = getProperties(event.getElement());
            elementProperty.getItems().setAll(elementProperties);
        } else {
            elementProperty.getItems().clear();
        }
    }

    private <T> void bindStatusBar(Service<T> service) {
        statusBar.textProperty().unbind();
        statusBar.progressProperty().unbind();
        statusBar.textProperty().bind(service.messageProperty());
        statusBar.progressProperty().bind(service.progressProperty());
    }

}
