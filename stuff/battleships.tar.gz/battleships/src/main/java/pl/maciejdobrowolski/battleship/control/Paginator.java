package pl.maciejdobrowolski.battleship.control;

import static javafx.beans.binding.Bindings.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class Paginator extends HBox implements Initializable {

    private static final Logger LOGGER = LoggerFactory.getLogger(Paginator.class);

    private SimpleIntegerProperty currentPage = new SimpleIntegerProperty(1);
    private SimpleIntegerProperty maxPages = new SimpleIntegerProperty(1);

    @FXML
    private Label label;

    @FXML
    private Button previousButton;

    @FXML
    private Button nextButton;

    public Paginator() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/controls/paginator.fxml"));
        loader.setRoot(this);
        loader.setController(this);

        try {
            loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nextButton.disableProperty().bind(greaterThanOrEqual(currentPage, maxPages));
        nextButton.setOnAction(event -> setCurrentPage(getCurrentPage() + 1));

        previousButton.disableProperty().bind(lessThanOrEqual(currentPage, 1));
        previousButton.setOnAction(event -> setCurrentPage(getCurrentPage() - 1));

        SimpleStringProperty pageWord = new SimpleStringProperty("Page ");
        label.textProperty().bind(pageWord.concat(currentPage).concat(" of ").concat(maxPages));
    }

    public int getCurrentPage() {
        return currentPage.get();
    }

    public SimpleIntegerProperty currentPageProperty() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage.set(currentPage);
    }

    public int getMaxPages() {
        return maxPages.get();
    }

    public SimpleIntegerProperty maxPagesProperty() {
        return maxPages;
    }

    public void setMaxPages(int maxPages) {
        this.maxPages.set(maxPages);
    }

}
