package pl.maciejdobrowolski.battleship.service;

import static java.util.Objects.*;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import pl.maciejdobrowolski.battleship.data.Project;

public class ProjectSaveService extends Service<Boolean> {

    private ProjectSaver projectSaver = new ProjectSaver();

    private Project project;

    @Override
    protected Task<Boolean> createTask() {
        return new AbstractTask<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                requireNonNull(project);
                projectSaver.save(project);
                return true;
            }
        };
    }

    public void save(Project project) {
        this.project = project;
        reset();
        start();
    }

}
