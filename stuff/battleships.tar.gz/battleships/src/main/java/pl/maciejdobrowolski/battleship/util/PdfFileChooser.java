package pl.maciejdobrowolski.battleship.util;

import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.File;
import java.util.Optional;

public class PdfFileChooser {

    private final Window window;

    public PdfFileChooser(Window window) {
        this.window = window;
    }

    public Optional<File> selectPdfFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        return Optional.ofNullable(fileChooser.showOpenDialog(window));
    }

}
