package pl.maciejdobrowolski.battleship.service.xml;

import java.io.InputStream;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import pl.maciejdobrowolski.battleship.data.Element;

public class XmlReaderWriter {

    private XStream xStream = new XStream(new DomDriver("UTF-8"));
    private XmlDataConverter xmlDataConverter = new XmlDataConverter();

    public XmlReaderWriter() {
        xStream.processAnnotations(Stamps.class);
        xStream.processAnnotations(Text.class);
    }

    public List<Element> textFromXml(InputStream inputStream){
        Stamps stamps = (Stamps) xStream.fromXML(inputStream);
        return xmlDataConverter.toElements(stamps.getItems());
    }

    public List<Element> textFromXml(String string){
        Stamps stamps =  (Stamps) xStream.fromXML(string);
        return xmlDataConverter.toElements(stamps.getItems());
    }

    public String toXml(List<Element> elements){
        Stamps stamps = new Stamps(xmlDataConverter.fromElements(elements));
        return "<?xml version=\"1.0\"?>\n" + xStream.toXML(stamps);
    }
}