package pl.maciejdobrowolski.battleship.service;

import static java.util.Collections.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import pl.maciejdobrowolski.battleship.data.Element;
import pl.maciejdobrowolski.battleship.service.xml.XmlReaderWriter;

class XmlFileLoader {

    private XmlReaderWriter readerWriter = new XmlReaderWriter();

    List<Element> loadDocumentElementsForPDF(File xmlFile) {
        if (xmlFile.exists()) {
            return readFile(xmlFile);
        } else {
            return emptyList();
        }
    }

    private List<Element> readFile(File xmlFile) {
        try (FileInputStream inputStream = new FileInputStream(xmlFile)) {
            return readerWriter.textFromXml(inputStream);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
