package pl.maciejdobrowolski.battleship.service;

import static javafx.scene.control.ProgressIndicator.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.concurrent.Task;

public abstract class AbstractTask<T> extends Task<T> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractTask.class);

    protected void notifyStart(String message) {
        updateMessage(message);
        showProgress();
    }

    protected void notifyEnd(String message) {
        updateMessage(message);
        hideProgress();
    }

    protected void notifyError(String errorMessage, Exception e) {
        LOGGER.error(errorMessage, e);
        updateMessage(errorMessage);
        hideProgress();
    }

    private void showProgress() {
        updateProgress(INDETERMINATE_PROGRESS, INDETERMINATE_PROGRESS);
    }

    private void hideProgress() {
        updateProgress(1, 1);
    }

}
