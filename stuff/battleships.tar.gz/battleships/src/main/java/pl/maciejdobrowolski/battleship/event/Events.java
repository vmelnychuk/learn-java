package pl.maciejdobrowolski.battleship.event;

import com.google.common.eventbus.EventBus;

public class Events {

    private static EventBus EVENT_BUS = new EventBus();

    public static void fire(Object event) {
        EVENT_BUS.post(event);
    }

    public static <T> T register(T subscriber) {
        EVENT_BUS.register(subscriber);
        return subscriber;
    }


}
