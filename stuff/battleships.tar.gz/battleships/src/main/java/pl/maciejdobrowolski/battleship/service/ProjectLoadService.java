package pl.maciejdobrowolski.battleship.service;

import static java.util.Objects.*;

import java.io.File;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import pl.maciejdobrowolski.battleship.data.Project;

public class ProjectLoadService extends Service<Project> {

    private static final String ERROR_WHILE_LOADING_PROJECT = "Error while loading project";
    private static final String PROJECT_LOADING_IN_PROGRESS = "Project loading in progress..";
    private static final String PROJECT_LOADING_FINISHED = "Project loading finished";
    private static final String PDF_FILE_NOT_SET = "Pdf file not set";

    private final ProjectLoader projectLoader = new ProjectLoader();
    private File pdfFile;

    @Override
    protected Task<Project> createTask() {
        return new AbstractTask<Project>() {
            @Override
            protected Project call() throws Exception {
                File file = requireNonNull(pdfFile, PDF_FILE_NOT_SET);
                notifyStart(PROJECT_LOADING_IN_PROGRESS);
                Project project;
                try {

                    project = projectLoader.load(file);
                    notifyEnd(PROJECT_LOADING_FINISHED);
                } catch (Exception e) {
                    project = Project.EMPTY_PROJECT;
                    notifyError(ERROR_WHILE_LOADING_PROJECT, e);
                }
                return project;
            }
        };
    }

    public void load(File pdfFile) {
        this.pdfFile = pdfFile;
        reset();
        start();
    }

}
