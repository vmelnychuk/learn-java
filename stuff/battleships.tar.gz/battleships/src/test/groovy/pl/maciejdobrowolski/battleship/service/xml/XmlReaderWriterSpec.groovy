package pl.maciejdobrowolski.battleship.service.xml

import org.xml.sax.InputSource
import pl.maciejdobrowolski.battleship.data.Element
import spock.lang.Specification
import spock.lang.Subject

import javax.xml.xpath.XPath
import javax.xml.xpath.XPathExpression
import javax.xml.xpath.XPathFactory

import static javafx.scene.text.Font.loadFont

class XmlReaderWriterSpec extends Specification {

    @Subject
    XmlReaderWriter readerWriter = new XmlReaderWriter()

    def 'should load Element from string'() {
        given:
            String xml = '<?xml version="1.0"?><stamps><text x="0" y="0" pageNumber="0"/></stamps>'
        when:
            List<Element> texts = readerWriter.textFromXml(xml)
        then:
            texts.first().x == 0
            texts.first().y == 0
            texts.first().pageNumber == 0
    }

    def 'should load Element from resource'() {
        when:
            List<Element> texts = readerWriter.textFromXml(getClass().getResourceAsStream("/sampleData.xml"))
        then:
            texts[0].x == 510
            texts[0].y == 751
            texts[0].pageNumber == 1
            texts[0].text == '${bank.clientNumber}'
    }

    def 'should save Element to XML'() {
        given:
            Element element = new Element()
            element.x = 510
            element.y = 751
            element.pageNumber = 1
            element.text = 'content'
            element.font = loadFont(getClass().getResourceAsStream("/ARIAL.TTF"), 12.0)
        when:
            String xml = readerWriter.toXml([element])
        then:
            getXmlValue(xml, "/stamps/text[1]/@x") == "510"
            getXmlValue(xml, "/stamps/text[1]/@y") == "751"
            getXmlValue(xml, "/stamps/text[1]/@pageNumber") == "1"
            getXmlValue(xml, "/stamps/text[1]/@text") == "content"
            getXmlValue(xml, "/stamps/text[1]/@fontName") == "Arial"
            getXmlValue(xml, "/stamps/text[1]/@fontSize") == "12.0"
    }

    private static String getXmlValue(String xml, String query) {
        XPathFactory xPathFactory = XPathFactory.newInstance()
        XPath xPath = xPathFactory.newXPath()
        XPathExpression expression = xPath.compile("string($query)")
        InputSource sourceXml = new InputSource(new StringReader(xml))
        return expression.evaluate(sourceXml)
    }

}
